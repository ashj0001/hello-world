var express = require('express');
var app = express();
app.disable('x-powered-by');
var handlebars = require('express-handlebars');
var formidable = require('formidable');
var credentials = require('./credentials.js');
var Adminlogin = require('./models/adminlogin.js');
var Vendorcrud = require('./models/vendorcrud.js');
var Categorycrud = require('./models/category.js');
var Areacrud = require('./models/areas.js');
var Dishcrud = require('./models/dishcrud.js');
var mongoose = require('mongoose');
var bodyParser = require('body-parser')
app.engine('handlebars', handlebars({defaultLayout:false}));
app.set('view engine', 'handlebars');

app.use(bodyParser.urlencoded({extended: false}));
app.use(bodyParser.json())

app.use(require('cookie-parser')(credentials.cookieSecret));

var bcrypt = require('bcrypt');
const saltRounds = 10;
var session = require('express-session');
app.use(session({
  resave: false,
  saveUninitialized: true,
  secret: credentials.cookieSecret,
}));
var Users = [];

mongoose.connect('mongodb://localhost:27017/zingger');


app.set('port', process.env.PORT || 3000);
app.use(express.static(__dirname + '/public'));

//fontenduser
app.get('/', function(req, res){
  if(req.session.vendor)
  {
    res.redirect('vendorhome');
  }else if(req.session.user)
  {
    res.redirect('adminhome');
  }else
  {
    res.render('user',{layout:false});
  }
});
//frontenduser

app.get('/admin', function(req, res){
   if(req.session.vendor)
  {
    res.redirect('vendorhome');
  }else if(req.session.user)
  {
    res.redirect('adminhome');
  }else
  {
 res.render('adminlogin', { title: 'admin login', layout: false });
   }
 
});

app.post('/adminlogin', function(req, res){
if(!req.body.username || !req.body.password){
        res.status("400");
        res.send("Invalid details!");
    }
    else{
        Adminlogin.getadmin(req.body.username, (err, admin) => {
        if(err){
           throw err;
        }else{
          if(typeof admin[0] !== 'undefined'){
          bcrypt.compare(req.body.password, admin[0]['password'], function(err, resp) {
                if(err){
                   throw err;
                   console.log(err);
                 }else{
                    if(resp==true)
                            {
                                var newUser = {id: admin[0]['_id'], username: req.body.username};
                                Users.push(newUser);
                                req.session.user = newUser;
                                res.redirect('/adminhome');
                            }
                            else{
                               res.render('adminlogin',{message:'invalid username or password'});
                            }
                 }
            });
          }else{
            res.status("400");
            res.send("Invalid details!");
          }
        }

       });
    }
});

app.post('/vendorlogin', function(req, res){
if(!req.body.username || !req.body.password){
        res.status("400");
        res.send("Invalid details!");
    }
    else{
        Vendorcrud.getvendor(req.body.username, (err, vendor) => {
        if(err){
           throw err;
        }else{
          if(typeof vendor[0] !== 'undefined'){
          bcrypt.compare(req.body.password, vendor[0]['password'], function(err, resp) {
                if(err){
                   throw err;
                   console.log(err);
                 }else{
                    if(resp==true)
                            {
                                var newUser = {id: vendor[0]['_id'], username: req.body.username};
                                Users.push(newUser);
                                req.session.vendor = newUser;
                                res.redirect('/vendorhome');
                            }
                            else{
                               res.render('vendorlogin',{message:'invalid username or password'});
                            }
                 }
            });
          }else{
            res.status("400");
        res.send("Invalid details!");
          }
        }

       });
    }
});

app.get('/logout', function(req, res){
  if(req.session.user)
  {
    var pathtoredirect ='admin';
  }else if(req.session.vendor){
    var pathtoredirect ='vendor';
  }else{
    var pathtoredirect ='/';
  }
    req.session.destroy(function(){
        console.log("user logged out.")
    });
    res.redirect(pathtoredirect);
});


app.use(function(req, res, next){
  console.log("Looking for URL : " + req.url);
  next();
});

//adminroutes
app.get('/all-vendors', checkSignIn, function(req, res){
   Vendorcrud.getallvendor((err, vendorall) => {
        if(err){
           throw err;
        }else{
          res.json(vendorall);
        }
      });
});

app.get('/adminhome', checkSignIn, function(req, res){  
   res.render('home',{ title: 'Admin',layout:'main' });
});

app.get('/create-vendor', checkSignIn, function(req, res){
  /*if(req.session.error)
  {*/
  // res.render('create-vendor',{layout:'main'});
      Areacrud.getallarea((err, allareas) => {
        if(err){
           throw err;
        }else{
          res.render('create-vendor',{layout:'main',allareas:allareas});
        }
      });

  /*}else{
   res.render('create-vendor',{layout:'main'});    
  }*/
  
});
app.get('/create-area', checkSignIn, function(req, res){
  var now = new Date();
  res.render('area_views/create-area',{layout:'main',now:now });
 });
app.get('/all-area', checkSignIn, function(req, res){
   Areacrud.getallarea((err, allareas) => {
        if(err){
           throw err;
        }else{
          res.json(allareas);
        }
      });
});
app.get('/tool-to-test-all-apis', checkSignIn, function(req, res){
   res.render('tool-to-test-all-apis',{layout:'main'});
   /*Areacrud.getallarea((err, allareas) => {
        if(err){
           throw err;
        }else{
          res.json(allareas);
        }
      });*/
});
app.post('/area-create', checkSignIn, function(req, res){
   var area = req.body; 
   if(!area.name || !area.date){
      res.redirect('/create-area');
      console.log('formerror')
   } else {
      var newArea = new Areacrud({
         name: area.name,
         created_at:  area.date
      });
        Areacrud.addArea(newArea, (err, area) => {
        if(err){
          throw err;
        }
        res.json(area);
      });

   }
});
app.get('/all-category', checkSignIn, function(req, res){
   Categorycrud.getallcategory((err, allcategories) => {
        if(err){
           throw err;
        }else{
          res.json(allcategories);
        }
      });
});

app.get('/create-category', checkSignIn, function(req, res){
  var now = new Date();
  res.render('category_views/create-category',{title:'Create category',layout:'main',now:now});
 });

app.post('/create-category', checkSignIn, function(req, res){
   var category = req.body; 
   if(!category.name || !category.date){
      res.redirect('/create-category');
      console.log('formerror')
   } else {
      var newCategory = new Categorycrud({
         name: category.name,
         searchtag: category.search,
         sortorder: category.order,
         created_at:  category.date
      });
        Categorycrud.addcategory(newCategory, (err, category) => {
        if(err){
          throw err;
        }
        res.json(category);
      });

   }
});
//adminroutes

//vendorroutes
app.get('/vendor', function(req, res){
  if(req.session.vendor)
  {
    res.redirect('vendorhome');
  }else if(req.session.user)
  {
    res.redirect('adminhome');
  }else
  {
    res.render('vendor_views/vendor',{layout:false});
  }
 
});

app.get('/vendorhome', checkSignInvendor, function(req, res){  
   res.render('vendor_views/vendorhome',{ title: 'my other page',layout:'vendorlay' });
});

//vendorroutes

//dishstart
app.get('/create-dish', checkSignInvendor, function(req, res){
  var now = new Date();
  var isadmin='';
  var vendordata='';
  if(req.session.user)
  {
    var layoutpath ='main';
    isadmin ='yes';
  }else if(req.session.vendor){
    var layoutpath ='vendorlay';
  }else{
    var layoutpath = false;
  }
   Vendorcrud.getallvendor((err, allvendor) => {
        if(err){
           throw err;
        }else{
          vendordata = allvendor;
        }
      });

   Categorycrud.getallcategory((err, allcategory) => {
        if(err){
           throw err;
        }else{
          res.render('vendor_views/create-dish',{layout:layoutpath,allcategories:allcategory,vendordata:vendordata,now:now,isadmin:isadmin});
        }
      });
  });

app.get('/all-dish', checkSignIn, function(req, res){
  Dishcrud.getalldish((err, dishall) => {
        if(err){
           throw err;
        }else{
          res.json(dishall);
        }
      });
  });
app.get('/vendor-dish', checkSignInvendor, function(req, res){
  //console.log(req.session.vendor.id);
 if(req.session.vendor.id){
      Dishcrud.getvendordish(req.session.vendor.id, (err, dishall) => {
        if(err){
           throw err;
        }else{
          res.json(dishall);
        }
      });
 }else{
  res.redirect('/vendor');
 }
  });

app.post('/dish-create', checkSignInvendor, function(req, res){
   var dish = req.body;
   created_by = '';
   if(req.session.vendor)
   {
    vendor_id = req.session.vendor.id;

   }else{
    vendor_id = dish.vendor_id;
    created_by = req.session.user.username;
   }
   if(!dish.name || !dish.search || !dish.order || !dish.category || !vendor_id ){
      res.redirect('/create-dish');
      console.log('formerror')
   } else {
      var newDish = new Dishcrud({
         name: dish.name,
         searchtag: dish.search,
         order: dish.order,
         category_id:  dish.category,
         created_at:  dish.date,
         vendor_id:  vendor_id,
         created_by: created_by
      });
        Dishcrud.addDish(newDish, (err, dish) => {
        if(err){
          throw err;
        }
        res.json(dish);
      });

   }
});
app.delete('/api/dish_remove/:_id', (req, res) => {
  var id = req.params._id;
  console.log(id);
  Dishcrud.removeDish(id, (err, dish) => {
    if(err){
      throw err;
    }
    res.json(dish);
  });
});

app.put('/api/dish_update/:_id', (req, res) => {
  res.send(req.body);
  var id = req.params._id;
  var dish = req.body;
  //console.log(dish);
  
  /*Dishcrud.updateDish(id, dish, {}, (err, dish) => {
    if(err){
      throw err;
    }else{
    res.json(dish);
    }
  });*/
});
//dishend

function checkSignIn(req, res,next){
  console.log(req.session.user);
    if(req.session.user){
        next();     //If session exists, proceed to page
    } else {
        

        var err = new Error("Not logged in!");
        res.render('adminlogin',{ title:'Zingger Login',message: 'please login don\'t try to become so smart',layout:false });
    }
}
function checkSignInvendor(req, res,next){
  console.log(req.session.vendor);
    if(req.session.vendor || req.session.user){
        next();     //If session exists, proceed to page
    } else {
      
        var err = new Error("Not logged in!");
        res.redirect('/');
        //res.render('user',{ title:'Zingger Login',message: 'please login don\'t try to become so smart',layout:false });
    }
}

//vendorcrudstart
app.post('/vendor-create', checkSignIn, function(req, res){
   var personInfo = req.body; 
   if(!personInfo.name || !personInfo.email || !personInfo.location || !personInfo.password || personInfo.password!=personInfo.cpassword){
      
      req.session.error = 'Something is wrong with form details';
      res.redirect('/create-vendor');
      console.log('formerror')
   } else {
  var pass = personInfo.password;
    bcrypt.hash(pass, saltRounds, function(err, hash) {
      
  var newVendor = new Vendorcrud({
         name: personInfo.name,
         email: personInfo.email,
         location: personInfo.location,
         password: hash
      });
  console.log(newVendor);
      Vendorcrud.addVendor(newVendor, (err, vendor) => {
        if(err){
          throw err;
        }
        res.json(vendor);
      });
});
   }
});

app.delete('/api/vendor_remove/:_id', (req, res) => {
  var id = req.params._id;
  console.log(id);
  Vendorcrud.removeVendor(id, (err, vendor) => {
    if(err){
      throw err;
    }
    res.json(vendor);
  });
});

app.put('/api/vendor_update/:_id', (req, res) => {
  var id = req.params._id;
  var vendor = req.body;
  Vendorcrud.updateVendor(id, vendor, {}, (err, vendor) => {
    if(err){
      throw err;
    }
    res.json(vendor);
  });
});
//vendorcrudend

app.get('*',function(req, res){
  res.type('text/html');
  res.status(404);
  res.render('404');
});

app.listen(app.get('port'), function(){
  console.log('Express started on http://localhost:' + app.get('port') + ' press Ctrl-C to terminate');
});