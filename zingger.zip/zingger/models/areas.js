const mongoose = require('mongoose');

var areaSchema = mongoose.Schema({
   name:{
		type: String,
		required: true,
		unique: true
	},
	created_at: Date
	
});
var Area = mongoose.model("areas", areaSchema);
module.exports = Area;

module.exports.getallarea = (callback, limit) => {
	Area.find(callback).limit(limit);
}
module.exports.addArea = (area, callback) => {
	Area.create(area, callback);
}