const mongoose = require('mongoose');

var dishSchema = mongoose.Schema({
   name:{
		type: String,
		required: true,
		unique: true
	},
	searchtag:{
		type: String,
		required: true
	},
	order:{
		type: Number,
		required: true
	},
	category_id:{
		type: String,
		required: true
	},
	vendor_id:{
		type: String,
		required: true
	},
	created_by:{
		type: String
	},
	created_at: Date
});

var Dish = mongoose.model("dish", dishSchema);

module.exports = Dish;

module.exports.getalldish = (callback, limit) => {
	Dish.find(callback).limit(limit);
}
module.exports.getvendordish = (vendor_id,callback) => {
	Dish.find({'vendor_id' : vendor_id},callback);
}
module.exports.addDish = (dish, callback) => {
	Dish.create(dish, callback);
}
module.exports.removeDish = (id, callback) => {
	var query = {_id: id};
	Dish.remove(query, callback);
}
module.exports.updateDish = (id, dish, options, callback) => {
	console.log(dish);
	var query = {_id: id};
	var update = {
		name: dish.name
	}
	console.log(update);
	Dish.findOneAndUpdate(query, update, options, callback);
}