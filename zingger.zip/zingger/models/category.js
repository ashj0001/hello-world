const mongoose = require('mongoose');

var categorySchema = mongoose.Schema({
   name:{
		type: String,
		required: true,
		unique: true
	},
	searchtag:{
		type: String,
		required: true
	},
	sortorder:{
		type: Number,
		required: true
	},
	created_at: Date
});
var Category = mongoose.model("categories", categorySchema);
module.exports = Category;

module.exports.getallcategory = (callback, limit) => {
	Category.find(callback).limit(limit);
}
module.exports.addcategory = (category, callback) => {
	Category.create(category, callback);
}