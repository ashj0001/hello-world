const mongoose = require('mongoose');

var vendorSchema = mongoose.Schema({
   name:{
		type: String,
		required: true,
		unique: true
	},
	email:{
		type: String,
		required: true
	},
	location:{
		type: String,
		required: true
	},
	password:{
		type: String
		//required: true
	},
	created_at: Date,
});
var Vendor = mongoose.model("vendor", vendorSchema);

module.exports = Vendor;

module.exports.getvendor = (username,callback) => {
	console.log(username);
	Vendor.find({'email':username},callback);
}

module.exports.getallvendor = (callback, limit) => {
	Vendor.find(callback).limit(limit);
}

module.exports.addVendor = (vendor, callback) => {
	Vendor.create(vendor, callback);
}

module.exports.removeVendor = (id, callback) => {
	var query = {_id: id};
	Vendor.remove(query, callback);
}
module.exports.updateVendor = (id, vendor, options, callback) => {
	var query = {_id: id};
	var update = {
		name: vendor.name,
		email: vendor.email,
		location: vendor.location
	}
	Vendor.findOneAndUpdate(query, update, options, callback);
}